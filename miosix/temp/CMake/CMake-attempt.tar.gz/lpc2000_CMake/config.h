
#ifndef _CONFIG_H
#define	_CONFIG_H

//
// Configuration options. The other options are in Makefile.inc
//

/*
 * Select behaviour in case of heap overflow. There are three options
 * 1) Uncomment EXIT_ON_HEAP_OVERFLOW, in this case a heap overflow will
 *    call exit() that will reboot the microcontrollers. (Like a reset)
 * 2) Leave EXIT_ON_HEAP_OVERFLOW commented, and enable C++ exceptions in
 *    Makefile.inc. In this case on heap overflow malloc() will return NULL
 *    and operator new will throw the bad_alloc exception. (Standard behaviour)
 * 3) Leave EXIT_ON_HEAP_OVERFLOW commented, and disable exceptions in
 *    Makefile.inc. In this case both malloc and operator new will return NULL.
 *    This is dangerous since C++ code, including the standard library, does
 *    not expect new to return NULL. Use with great care.
 */
#define EXIT_ON_HEAP_OVERFLOW

/**
 * This allows to choose between an interrupt-based or a busy wait based
 * implementation for delay_ms(). The interrupt-based version has the advantage
 * of putting the CPU in idle mode to reduce power consumption, but it uses the
 * SysTick timer. If you intend to use SysTick then choose the busy wait
 * implementation.
 */
//#define DELAY_IS_INTERRUPT_BASED

/**
 * If using functions that access stdin, like fgets or scanf uncomment
 * this to avoid the allocation of a 1KB buffer by the C stadard library.
 * If not using stdin, it is better to leave this commented out since it saves
 * code size.
 * Note: this also has the advantage of fixing this bug in newlib 1.17.0
 * http://old.nabble.com/getchar-issues-td15965394.html
 */
//#define USE_STDIN

#endif	/* _CONFIG_H */
