
#include "libraries/system.h"

int main()
{
    init();
    shutdown();
}