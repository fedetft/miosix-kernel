/***************************************************************************
 *   Copyright (C) 2007, 2008, 2009, 2010 by Terraneo Federico             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   As a special exception, if other files instantiate templates or use   *
 *   macros or inline functions from this file, or you compile this file   *
 *   and link it with other works to produce a work based on this file,    *
 *   this file does not by itself cause the resulting work to be covered   *
 *   by the GNU General Public License. However the source code for this   *
 *   file must still be made available in accordance with the GNU General  *
 *   Public License. This exception does not invalidate any other reasons  *
 *   why a work based on this file might be covered by the GNU General     *
 *   Public License.                                                       *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, see <http://www.gnu.org/licenses/>   *
 ***************************************************************************/

#ifndef SYSTEM_H
#define SYSTEM_H

#include "LPC213x.h"
#include <stdio.h>

/*
 * system.h  --- v3.00
 * Developed by TFT: Terraneo Federico Technologies
 * Collection of "utilities" for the NXP LPC2138 ARM7 Processor
 */

//
// Init
//

/**
 * xtal clock frequency. Library is *untested* with values different
 * from 14745600. Also, busy wait delay code has this frequency hardcoded.
 */
const unsigned int F_CLK=14745600;

/**
 * Initalizes the microcontroller: set PLL, UART, TIMER...
 */
void init();

/**
 * Put cpu to low power mode when application stops
 */
void shutdown();

//
// Interrupts
//

/**
 * Disables interrupts, both IRQ and FIQ
 */
inline void interrupts_enable()
{
    asm volatile(".set  I_BIT, 0x80            \n\t"
                 ".set  F_BIT, 0x40            \n\t"
                 "mrs r0, cpsr                 \n\t"
                 "and r0, r0, #~(I_BIT|F_BIT)  \n\t"
                 "msr cpsr_c, r0               \n\t"
                 :::"r0");
}

/**
 * Enables interrupts, both IRQ and FIQ
 */
inline void interrupts_disable()
{
    asm volatile(".set  I_BIT, 0x80            \n\t"
                 ".set  F_BIT, 0x40            \n\t"
                 "mrs r0, cpsr                 \n\t"
                 "orr r0, r0, #I_BIT|F_BIT     \n\t"
                 "msr cpsr_c, r0               \n\t"
                 :::"r0");
}

extern "C" void Timer1_IRQ_Routine (void)   __attribute__ ((interrupt("IRQ")));
extern "C" void FIQ_Routine (void)   __attribute__ ((interrupt("FIQ")));
extern "C" void SWI_Routine (void)   __attribute__ ((interrupt("SWI")));
extern "C" void UNDEF_Routine (void) __attribute__ ((interrupt("UNDEF")));

//
// Utils
//

/**
 * Delay function. Accurate within +/- 1ms.
 * It is implemented using busy wait or timer 1 interrupts depending on a flag
 * defined in system.cpp. If interrupt-based implementation is chosen puts the
 * CPU in low power (idle) mode while waiting.
 * \param mseconds milliseconds to wait
 */
void delay_ms(unsigned int mseconds);

/**
 * Delay function. Sort of accurate for delays greater than 10 microseconds.
 * For best accuracy make sure interrupts are disabled, or the time to service
 * interrupts will cause longer delays.
 * \param useconds microseconds to wait. Only values between 1 and 1000 are
 * allowed. For greater delays use delay_ms().
 */
void delay_us(unsigned int useconds);


//Bits of PCON register
#define IDL (1<<0)
#define PD (1<<1)
#define BODPDM (1<<2)
#define BOGD (1<<3)
#define BORD (1<<4)

/**
 * Halt CPU while peripherals remain active.
 * Any peripheral interrupt will wake the cpu
 */
inline void go_idle()
{
    PCON|=IDL;
}

/**
 * Halt both cpu and peripherals
 */
inline void go_power_down()
{
    PCON|=BODPDM | PD;
}

/**
 * Jump to reset vector (reboot)
 */
inline void system_reboot()
{
    asm volatile("ldr pc, =0"::);
}

/**
 * Prints absolute (not current) free stack.
 */
inline void print_free_stack()
{
    //These extern variables are defined in LPC2138_rom.ld
    //Pointer to beginning of stack
    extern const char _stack_start asm("_stack_start");
    //Pointer to end of stack
    extern const char _sys_stack_top asm("_sys_stack_top");
    const char *walk=&_stack_start;
    while(*walk==0xbb) walk++;//Free stack is watermarked with 0xbb
    walk--;
    iprintf("Stack statistics:\r\n"
            "Used  %u\r\n"
            "Free  %u\r\n"
            "Total %u\r\n",
            (unsigned int)&_sys_stack_top - (unsigned int)walk,
            (unsigned int)walk - (unsigned int)&_stack_start,
            (unsigned int)&_sys_stack_top - (unsigned int)&_stack_start);
}

///no operation instruction
#define nop() { asm volatile("nop"::); }

//
// UART0
//

/**
 * Initializes uart0
 * div=(peripheral clock)/(16*baudrate)
 */
void uart0_init(unsigned long div);


/**
 * \return true if there is data to be read
 */
inline bool uart0_rx_check()
{
    return U0LSR & (1<<0);
}

/**
 * \return true if framing, overrun, rx error (or parity, but not enabled)
 */
inline bool uart0_error_check()
{
    return U0LSR & 0x8e;
}

/**
 * Reads data from uart, blocking until data arrives
 * \return character from uart
 */
char uart0_rx();

/**
 * \return true if uart is ready to transmit
 */
inline bool uart0_tx_check()
{
    return U0LSR & (1<<5);
}

/**
 * \return true if the uart tx buffer is empty. May be used to ensure all bytes
 * have been sent before entering power down mode
 */
inline bool uart0_fifo_empty()
{
    return U0LSR & (1<<6);
}

/**
 * Send a char to uart
 * \param data data to send
 */
void uart0_tx(const char data);

/**
 * Transmits a null-terminated string to uart
 * \param data string to send
 */
void uart0_tx_str(const char *data);

//
// System PLL
//

/**
 * Constants to pass to set_pll_freq(), and values returned by get_pll_freq()
 */
enum PllValues
{
    PLL_4X=4,   ///<AHB clock frequency = xtal freq. multiplied by 4
    PLL_2X=2,   ///<AHB clock frequency = xtal freq. multiplied by 2
    PLL_OFF=0,  ///<AHB clock frequency = xtal freq.
    PLL_UNDEF=-1///<Returned by get_pll_freq() in case of errors
};

/**
 * Set PLL frequency
 * <br>Warning! Disable interrupts before changing PLL frequency
 * <br>Warning! This is meant to work with a 14.7456MHz xtal, and is UNTESTED with other values
 * <br>Warning! Changing PLL frequency may cause problems to hardware drivers
 * \param r the desired PLL settings
 */
void set_pll_freq(PllValues r);

/**
 * Get PLL settings
 * Warning! This is meant to work with a 14.7456MHz xtal, and is UNTESTED with other values
 * \return the current PLL settings
 */
PllValues get_pll_freq();

/**
 * Constants to pass to set_apb_ratio(), and values returned by get_apb_ratio()
 */
enum APBValues
{
    APB_DIV_1=1,///<AHB and APB run @ same speed
    APB_DIV_2=2,///<APB runs at 1/2 of AHB frequency
    APB_DIV_4=0 ///<APB runs at 1/4 of AHB frequency
};

/**
 * Set apb ratio (how much peripherals are slowed down with respect to cpu)
 * \param r desired apb ratio
 */
inline void set_apb_ratio(APBValues r)
{
    VPBDIV=(r);
}

/**
 * Get apb ratio (how much peripherals are slowed down with respect to cpu)
 *\return current apb ratio
 */
inline APBValues get_apb_ratio()
{
    return (APBValues)(VPBDIV & 0x3);
}

#endif //SYSTEM_H
