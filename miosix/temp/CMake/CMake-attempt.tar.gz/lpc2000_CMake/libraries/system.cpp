/***************************************************************************
 *   Copyright (C) 2007, 2008, 2009, 2010 by Terraneo Federico             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   As a special exception, if other files instantiate templates or use   *
 *   macros or inline functions from this file, or you compile this file   *
 *   and link it with other works to produce a work based on this file,    *
 *   this file does not by itself cause the resulting work to be covered   *
 *   by the GNU General Public License. However the source code for this   *
 *   file must still be made available in accordance with the GNU General  *
 *   Public License. This exception does not invalidate any other reasons  *
 *   why a work based on this file might be covered by the GNU General     *
 *   Public License.                                                       *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, see <http://www.gnu.org/licenses/>   *
 ***************************************************************************/

#include "LPC213x.h"
#include "system.h"
#include "../config.h"

/*
 * system.cpp  --- v3.00
 * Developed by TFT: Terraneo Federico Technologies
 * Collection of "utilities" for the NXP LPC2138 ARM7 Processor
 */

//
// Init
//

void init()
{
    //Initialize the system pll
    set_pll_freq(PLL_4X);//Set cpu freq. through pll @ 14.7456MHz * 4 = 58MHz
    set_apb_ratio(APB_DIV_4);//Set peripheral clock ratio 1:4
    //IODIR0=0xffff3ffc; // P0 all output but p0.0, p0.1 p0.14 p0.15
    //IODIR1=0xffffffff; // All output
    //IOCLR0=0x7fffffff; // P0 all @ 0 but p0.31
    //IOSET0=0x80000000;
    //IOSET1=0xffffffff; // P1 all @ 1

    #ifdef DELAY_IS_INTERRUPT_BASED
    //Init timer 1
    T1TCR=0x0;//Stop timer
    T1TC=0x0;
    T1PR=0x0;
    T1PC=0x0;
    //Match value
    T1MR0=(14745600/1000);// Interrupt @ 1000Hz
    //Reset and interrupt on match
    T1MCR=0x3;
    //Init VIC
    VICIntSelect=0x0;//Timer1=IRQ
    VICIntEnable=0x20;//Timer1 interrupt ON
    VICVectCntl0=0x25;
    VICVectAddr0=(unsigned long)&Timer1_IRQ_Routine;
    T1TCR=0x1;//Start timer
    #endif //DELAY_IS_INTERRUPT_BASED

    uart0_init(F_CLK/16/115200);//(peripheral clock)/(16*baudrate)

    interrupts_enable();//Enable interrupts
    
	#ifdef USE_STDIN
    setbuf(stdin,NULL);//Avoid allocating a large buffer
    #endif //USE_STDIN
}

void shutdown()
{
    while(!uart0_fifo_empty());//Wait until all data sent
    interrupts_disable();
	go_power_down();
}

//
// Interrupts
//

 #ifdef DELAY_IS_INTERRUPT_BASED
volatile static bool timer_tick=false;

extern "C" void Timer1_IRQ_Routine(void)
{
    T1IR=0x1;//Clear interrupt
    VICVectAddr=0xff;
    timer_tick=true;
}
#endif //DELAY_IS_INTERRUPT_BASED

//Look up table used by print_unsigned_int
static const char hexdigits[]="0123456789abcdef";

/**
Used to print an unsigned int in hexadecimal format
Note that printf/iprintf cannot be used inside an IRQ, so that's why there's
this function.
*/
static void print_unsigned_int(unsigned int x)
{
    char result[]="0x........";
    for(int i=9;i>=2;i--)
    {
        result[i]=hexdigits[x & 0xf];
        x>>=4;
    }
    uart0_tx_str(result);
}

extern "C" void FIQ_Routine(void)
{
    uart0_tx_str("\r\n***Unexpected FIQ\r\n");
    while(!uart0_fifo_empty());//Wait until all data sent
    system_reboot();
}

extern "C" void SWI_Routine(void)
{
    uart0_tx_str("\r\n***Unexpected SWI\r\n");
    while(!uart0_fifo_empty());//Wait until all data sent
    system_reboot();
}

extern "C" void UNDEF_Routine(void)
{
    //These two instructions MUST be the first two instructions of the interrupt
    //routine. They store in return_address the pc of the instruction that
    //caused the interrupt with an error of +/-4bytes (since different
    //interrupts have different offsets). This is useful for debugging.
    volatile register int return_address asm("r5");
    asm volatile("	sub	r5,	lr,	#4	");

    uart0_tx_str("\r\n***Unexpected UNDEF @ ");
    print_unsigned_int(return_address);
    uart0_tx_str("\r\n");
    while(!uart0_fifo_empty());//Wait until all data sent
    system_reboot();
}

//
// Utils
//

void delay_ms(unsigned int mseconds)
{
    #ifdef DELAY_IS_INTERRUPT_BASED
    timer_tick=false;
    while(mseconds>0)
    {
        if(timer_tick)
        {
            timer_tick=false;
            mseconds--;
        } else go_idle();
    }
    #else //DELAY_IS_INTERRUPT_BASED
    for(unsigned int i=0;i<mseconds;i++)
    {
        // This delay has been calibrated to take 1 millisecond
        // if running with a 58982400Hz CPU clock. It is written in assembler
        // to be independent on compiler optimization settings
        asm volatile("           ldr   r1, =11788 \n"
                     "           mov   r2, #0     \n"
                     "___loop_m: cmp   r2, r1     \n"
                     "           addlo r2, r2, #1 \n"
                     "           blo   ___loop_m  \n":::"r1","r2");
    }
    #endif //DELAY_IS_INTERRUPT_BASED
}

void delay_us(unsigned int useconds)
{
    // This delay has been calibrated to take x microseconds
    // if running with a 58982400Hz CPU clock. It is written in assembler
    // to be independent on compiler optimization settings
    asm volatile("           ldr   r1, =12    \n"
                 "           mul   r2, %0, r1 \n"
                 "           mov   r1, #0     \n"
                 "___loop_u: cmp   r1, r2     \n"
                 "           addlo r1, r1, #1 \n"
                 "           blo   ___loop_u  \n"::"r"(useconds):"r1","r2");

}

//
// UART0
//

void uart0_init(unsigned long div)
{
    U0FCR=0x7;//Fifo enabled
    U0LCR=0x83;//8data bit, 1stop, no parity, DLAB enabled
    U0DLL=div & 0xff;
    U0DLM=(div>>8) & 0xff;
    U0LCR=0x3;//DLAB disabled
    PINSEL0&=~(0xf);//Clear bits 0 to 3 of PINSEL0
    PINSEL0|=0x5;//Set p0.0 as TXD and p0.1 as RXD
}

char uart0_rx()
{
    while(!uart0_rx_check());
    return U0RBR;
}

void uart0_tx(const char data)
{
    while(!uart0_tx_check());//Wait until ready
    U0THR=data;
}

void uart0_tx_str(const char *data)
{
    while((*data)!='\0') { uart0_tx(*data); data++; }
}

//
// System PLL
//

#define PLOCK 0x400

/**
Generates the PLL feed sequence
*/
static inline void feed()
{
    PLLFEED=0xAA;
    PLLFEED=0x55;
}

void set_pll_freq(PllValues r)
{
    PLLCON=0x0;//PLL OFF
    feed();
    switch(r)
    {
        case PLL_2X://PLL=2*F
            // Enabling MAM
            MAMCR=0x0;//MAM Disabled
            MAMTIM=0x2;//Flash access is 2 cclk
            MAMCR=0x2;//MAM Enabled
            // Setting PLL
            PLLCFG=0x41;// M=2 P=4 ( FCCO=14.7456*M*2*P=235MHz )
            feed();
            PLLCON=0x1;//PLL Enabled
            feed();
            while(!(PLLSTAT & PLOCK));//Wait for PLL to lock
            PLLCON=0x3;//PLL Connected
            feed();
            break;
        case PLL_4X://PLL=4*F
            // Enabling MAM
            MAMCR=0x0;//MAM Disabled
            MAMTIM=0x3;//Flash access is 3 cclk
            MAMCR=0x2;//MAM Enabled
            // Setting PLL
            PLLCFG=0x23;// M=4 P=2 ( FCCO=14.7456*M*2*P=235MHz )
            feed();
            PLLCON=0x1;//PLL Enabled
            feed();
            while(!(PLLSTAT & PLOCK));//Wait for PLL to lock
            PLLCON=0x3;//PLL Connected
            feed();
            break;
        default://PLL OFF
            // Enabling MAM
            MAMCR=0x0;//MAM Disabled
            MAMTIM=0x1;//Flash access is 1 cclk
            MAMCR=0x2;//MAM Enabled
            break;
    }
}

PllValues get_pll_freq()
{
    //If "pll off" or "pll not connected" return PLL_OFF
    if((PLLSTAT & 0x300)!=0x300) return PLL_OFF;
    switch(PLLSTAT & 0x7f)
    {
        case 0x41: return PLL_2X;
        case 0x23: return PLL_4X;
        default:   return PLL_UNDEF;//PLL undefined value
    }
}
