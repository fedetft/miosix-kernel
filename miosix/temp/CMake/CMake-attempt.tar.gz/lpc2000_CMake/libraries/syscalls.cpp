/***************************************************************************
 *   Copyright (C) 2007, 2008, 2009, 2010 by Terraneo Federico             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   As a special exception, if other files instantiate templates or use   *
 *   macros or inline functions from this file, or you compile this file   *
 *   and link it with other works to produce a work based on this file,    *
 *   this file does not by itself cause the resulting work to be covered   *
 *   by the GNU General Public License. However the source code for this   *
 *   file must still be made available in accordance with the GNU General  *
 *   Public License. This exception does not invalidate any other reasons  *
 *   why a work based on this file might be covered by the GNU General     *
 *   Public License.                                                       *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, see <http://www.gnu.org/licenses/>   *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <reent.h>
#include <sys/stat.h>
/* Low level serial port tx functions */
#include "system.h"
/* Configuration settings */
#include "../config.h"

extern "C" void _exit(int n); //Declared below

//If not using exceptions, ovverrde the default new, delete with
//an implementation that does not throw
#ifdef __NO_EXCEPTIONS
/**
new operator. Redefined not to throw exceptions. 
*/
void *operator new(size_t size)
{
    return malloc(size);
}

void *operator new[](size_t size)
{
    return malloc(size);
}

/**
delete operator. Redefined not to throw exceptions.
*/
void operator delete(void *p)
{
    free(p);
}

void operator delete[](void *p)
{
    free(p);
}

/**
The default version of this function provided with libstdc++ requires
exception support. This means that a program using pure virtual functions
incurs in the code size penalty of exception support even when compiling without
exceptions. By replacing the default implementation with this one the problem is
fixed.
*/
extern "C" void __cxa_pure_virtual(void)
{
    uart0_tx_str("pure virtual method called\r\n");
    _exit(1);//Not calling abort() since it pulls in malloc.
}
#endif //__NO_EXCEPTIONS

namespace __gnu_cxx {

/**
Replaces the default verbose terminate handler.
Avoids the inclusion of code to demangle C++ names.
*/
void __verbose_terminate_handler()
{
  uart0_tx_str("Exception thrown\r\n");
  _exit(1);//Not calling abort() since it pulls in malloc.
}

}//namespace __gnu_cxx

#ifdef __cplusplus
extern "C" {
#endif

#define STDIN_FILENO 0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2

/**
Required by C++ standard library.
See http://lists.debian.org/debian-gcc/2003/07/msg00057.html
*/
void *__dso_handle=(void*) &__dso_handle;

/**
_exit, restarts the system
*/
void _exit(int n)
{
    uart0_tx_str("\r\n***Exit called\r\n");
    while(!uart0_fifo_empty());//Wait until all data sent
    system_reboot();
    for(;;) /*lock*/;
}

/**
_sbrk_r, malloc calls it to increase the heap size
*/
void *_sbrk_r(struct _reent *ptr, ptrdiff_t incr)
{
    //This is the absolute start of the heap
    extern char _end asm("_end"); //defined in the linker script
    //This is the absolute end of the heap
    extern char _heap_end asm("_heap_end"); //defined in the linker script
    //This holds the current end of the heap (static)
    static char *cur_heap_end=NULL;
    //This holds the previous end of the heap
    char *prev_heap_end;

    //Check if it's first time called
    if(cur_heap_end==NULL) cur_heap_end=&_end;

    prev_heap_end=cur_heap_end;
    if((cur_heap_end+incr)>&_heap_end)
    {
        //bad, heap overflow
        #ifdef EXIT_ON_HEAP_OVERFLOW
        uart0_tx_str("\r\n***Heap overflow\r\n");
        _exit(1);
        #else //EXIT_ON_HEAP_OVERFLOW
        return reinterpret_cast<void*>(-1);
        #endif //EXIT_ON_HEAP_OVERFLOW
    }
    cur_heap_end+=incr;
    return reinterpret_cast<void*>(prev_heap_end);
}

/**
__malloc_lock, no need to lock malloc
*/
void __malloc_lock()
{
    //Do nothing
}

/**
__malloc_unlock, no need to lock malloc
*/
void __malloc_unlock()
{
    //Do nothing
}

/**
_open_r, unimplemented
*/
int _open_r(struct _reent *ptr, const char *file, int flags, int mode)
{
    return -1;
}

/**
_close_r, unimplemented
*/
int _close_r(struct _reent *ptr, int fd)
{
    return 0;
}

/**
_write (for C++ library)
*/
int _write(int fd, const void *buf, size_t cnt)
{
    if((fd==STDOUT_FILENO)||(fd==STDERR_FILENO))
    {
        char *tmp=(char *)buf;
        for(unsigned int i=0;i<static_cast<unsigned>(cnt);i++)
        {
            if(*tmp!='\n') uart0_tx(*tmp++);
            else uart0_tx_str("\r\n");
        }
    } else {
        uart0_tx_str("Error: _write\r\n");
        cnt = -1;
    }
    return cnt;
}

/**
_write_r
*/
int _write_r(struct _reent *ptr, int fd, const void *buf, size_t cnt)
{
    return _write(fd,buf,cnt);
}

/**
_read (for C++ library)
*/
int _read(int fd, void *buf, size_t cnt)
{
    //iprintf("read: buf %d\r\n",(int)cnt);//To check read buffer size
    char *buffer=(char*)buf;
    //Trying to be compatible with terminals that output \r, \n or \r\n
    //When receiving \r skip_terminate is set to true so we skip the \n if it
    //comes right after the \r
    static bool skip_terminate=false;
    if(fd==STDIN_FILENO)
    {
        for(int i=0;i<cnt;i++)
        {
            buffer[i]=uart0_rx();//FIXME: cpu busy wait, wastes power
            switch(buffer[i])
            {
                case '\r':
                    buffer[i]='\n';
                    uart0_tx_str("\r\n");//Echo
                    skip_terminate=true;
                    return i+1;
                    break;
                case '\n':
                    if(skip_terminate)
                    {
                        skip_terminate=false;
                        //Discard the \n because comes right after \r
                        //Note that i may become -1, but it is acceptable.
                        i--;
                    } else {
                        uart0_tx_str("\r\n");//Echo
                        return i+1;
                    }
                    break;
                default:
                    skip_terminate=false;
                    uart0_tx(buffer[i]);//Echo
            }
        }
        return cnt;
    } else {
        uart0_tx_str("Error: _read\r\n");
        return -1;
    }
}

/**
_read_r, unimplemented
*/
int _read_r(struct _reent *ptr, int fd, void *buf, size_t cnt)
{
    return _read(fd,buf,cnt);
}

/**
_lseek (for C++ library)
*/
off_t _lseek(int fd, off_t pos, int whence)
{
    return -1;
}

/**
_lseek_r, unimplemented
*/
off_t _lseek_r(struct _reent *ptr, int fd, off_t pos, int whence)
{
    return -1;
}

/**
_stat_r, unimplemented
*/
int _stat_r(struct _reent *ptr, const char *file, struct stat *pstat)
{
    return 0;
}

/**
_fstat (for C++ library)
*/
int _fstat(int fd, struct stat *pstat)
{
    if(fd==STDOUT_FILENO)
    {
        memset(pstat,0,sizeof(*pstat));//FIXME: sizeof(*pstat) is the size of the pointer??
        pstat->st_mode=S_IFCHR;
        pstat->st_blksize=1024;
        return 0;
    } else {
        return -1;
    }
}

/**
_fstat_r
*/
int _fstat_r(struct _reent *ptr, int fd, struct stat *pstat)
{
    return _fstat(fd,pstat);
}

/**
isatty, returns 1 if fd is associated with a terminal
*/
int isatty(int fd)
{
    switch(fd)
    {
        case STDIN_FILENO:
        case STDOUT_FILENO:
        case STDERR_FILENO:
            return 1;
        default:
            return 0;
    }
}

/**
_isatty, required
*/
int _isatty(int fd)
{
    return isatty(fd);
}

/**
_kill, it looks like abort() calls _kill instead of exit, this implementation
calls _exit() so that calling abort() really terminates the program
*/
int _kill(int pid, int sig)
{
    _exit(1);
}

/*--------------------------------------------
These functions are required by the C and C++
standard library, but will not be implemented
--------------------------------------------*/

/**
_fork_r, unimplemented
*/
int _fork_r(struct _reent *ptr)
{
    return -1;
}

/**
_wait_r, unimpemented
*/
int _wait_r(struct _reent *ptr, int *status)
{
    return -1;
}

/**
_link_r, unimpemented
*/
int _link_r(struct _reent *ptr, const char *f_old, const char *f_new)
{
    return -1;
}

/**
_unlink_r, unimplemented
*/
int _unlink_r(struct _reent *ptr, const char *file)
{
    return -1;
}

/**
_getpid, unimplemented  (don't even know if function signature is correct)
*/
int _getpid()
{
    return -1;
}

#ifdef __cplusplus
}
#endif
