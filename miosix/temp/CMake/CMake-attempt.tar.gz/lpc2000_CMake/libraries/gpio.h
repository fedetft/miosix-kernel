/***************************************************************************
 *   Copyright (C) 2009, 2010 by Terraneo Federico                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   As a special exception, if other files instantiate templates or use   *
 *   macros or inline functions from this file, or you compile this file   *
 *   and link it with other works to produce a work based on this file,    *
 *   this file does not by itself cause the resulting work to be covered   *
 *   by the GNU General Public License. However the source code for this   *
 *   file must still be made available in accordance with the GNU General  *
 *   Public License. This exception does not invalidate any other reasons  *
 *   why a work based on this file might be covered by the GNU General     *
 *   Public License.                                                       *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, see <http://www.gnu.org/licenses/>   *
 ***************************************************************************/

/*
 * Versions:
 * 1.0 First release
 * 1.1 Made Mode, Gpio and GpioBase constructor private to explicitly disallow
 *     creating instances of these classes.
 * 1.2 Fixed a bug
 * 1.3 Applied patch by Lee Richmond (http://pastebin.com/f7ae1a65f). Now
 *     mode() is inlined too.
 * 1.4 Backported this abstraction library on NXP LPC2138 microcontrollers
 */

#ifndef _GPIO_H
#define	_GPIO_H

#include "LPC213x.h"

/**
 * This class just encapsulates the Mode_ enum so that the enum names don't
 * clobber the global namespace. C++0x enum class, I need you.
 */
class Mode
{
public:
    /**
     * GPIO mode (INPUT, OUTPUT, ...)
     * \example pin::mode(Mode::INPUT);
     */
    enum Mode_
    {
        INPUT              = 0x0, ///Floating  Input
        OUTPUT             = 0x1, ///Push Pull Output
    };
private:
    Mode(); //Just a wrapper class, disallow creating instances
};

/**
 * Memory layout of the GPIOs in the LPC2138
 */
struct GpioMemoryLayout
{
    volatile unsigned int IOPIN;
    volatile unsigned int IOSET;
    volatile unsigned int IODIR;
    volatile unsigned int IOCLR;
};

const int GPIO0_BASE=0xe0028000;///Base address of GPIO0 registers
const int GPIO1_BASE=0xe0028010;///Base address of GPIO1 registers

/**
 * Gpio template class
 * \param P GPIO0_BASE or GPIO1_BASE. Select which port
 * \param N which pin (0 to 31)
 * The intended use is to make a typedef to this class with a meaningful name.
 * \example
 * typedef Gpio<GPIO0_BASE,0> green_led;
 * green_led::mode(Mode::OUTPUT);
 * green_led::high();//Turn on LED
 */
template<unsigned int P, unsigned char N>
class Gpio
{
public:
    /**
     * Set the GPIO to the desired mode (INPUT, OUTPUT)
     * \param m enum Mode_
     */
    static void mode(Mode::Mode_ m)
    {
        if(m==Mode::INPUT)
        {
            reinterpret_cast<GpioMemoryLayout*>(P)->IODIR &= ~(1<<N);
        } else {
            reinterpret_cast<GpioMemoryLayout*>(P)->IODIR |= (1<<N);
        }
    }

    /**
     * Set the pin to 1, if it is an output
     */
    static void high()
    {
        reinterpret_cast<GpioMemoryLayout*>(P)->IOSET= 1<<N;
    }

    /**
     * Set the pin to 0, if it is an output
     */
    static void low()
    {
        reinterpret_cast<GpioMemoryLayout*>(P)->IOCLR= 1<<N;
    }

    /**
     * Allows to read the pin status
     * \return 0 or 1
     */
    static int value()
    {
        return ((reinterpret_cast<GpioMemoryLayout*>(P)->IOPIN & 1<<N)? 1 : 0);
    }

private:
    Gpio();//Only static member functions, disallow creating instances
};

#endif	//_GPIO_H
